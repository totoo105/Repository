import pandas as pd
import numpy as np
from datetime import datetime, timedelta


class Strategy:
    """Strategy 5 — 小盘高波动标的的均值回归策略（简化版）。

    早期打包版本里，该策略混用了旧版 client 接口（get_account_equity/submit_order
    与 DataFrame 形式的 bars），导致策略无法运行。

    当前版本统一使用 client.get_bars()/get_buying_power()/buy()/sell()。
    """

    def __init__(self, client, symbol: str = "IWM", position_fraction: float = 0.1):
        self.client = client
        self.symbol = symbol
        self.position_fraction = position_fraction

        self.current_position = 0  # 1=多头, -1=空头, 0=空仓
        self.last_qty = 0
        self.last_signal_time = None

    def fetch_bars(self, limit: int = 300):
        """获取 5 分钟 K 线。"""
        try:
            bars = self.client.get_bars(self.symbol, "5Min", limit)
            if not bars:
                return None

            df = pd.DataFrame(
                {
                    "t": [b.timestamp for b in bars],
                    "c": [b.close for b in bars],
                }
            )
            df.set_index("t", inplace=True)
            return df
        except Exception as e:
            print(f"[Strategy5] fetch_bars error: {e}")
            return None

    def run(self):
        df = self.fetch_bars()
        if df is None or len(df) < 120:
            return

        close = df["c"].astype(float)

        # Bollinger Bands (20)
        ma = close.rolling(20).mean()
        std = close.rolling(20).std()
        upper = ma + 2 * std
        lower = ma - 2 * std

        last = close.iloc[-1]
        last_upper = upper.iloc[-1]
        last_lower = lower.iloc[-1]
        last_ma = ma.iloc[-1]

        # 简易 RSI 过滤（避免强趋势里过早逆势）
        delta = close.diff()
        gain = delta.clip(lower=0).rolling(14).mean()
        loss = (-delta.clip(upper=0)).rolling(14).mean()
        rs = gain / loss
        rsi = 100 - (100 / (1 + rs))
        rsi_last = rsi.iloc[-1]

        now = datetime.utcnow()
        if self.last_signal_time and now - self.last_signal_time < timedelta(minutes=10):
            return

        price = float(last)
        buying_power = float(self.client.get_buying_power())
        qty = int((buying_power * float(self.position_fraction)) / price)
        if qty <= 0:
            return

        # 均值回归：触及下轨 + RSI 偏弱 -> 做多；触及上轨 + RSI 偏强 -> 做空
        if last <= last_lower and rsi_last < 45 and self.current_position <= 0:
            # 平空
            if self.current_position == -1 and self.last_qty > 0:
                self.client.buy(self.symbol, self.last_qty)
            self.client.buy(self.symbol, qty)
            self.current_position = 1
            self.last_qty = qty
            self.last_signal_time = now
            print(f"[Strategy5] BUY {self.symbol} qty={qty} @ {price} (BB lower)")
            return

        if last >= last_upper and rsi_last > 55 and self.current_position >= 0:
            # 平多
            if self.current_position == 1 and self.last_qty > 0:
                self.client.sell(self.symbol, self.last_qty)
            self.client.sell(self.symbol, qty)
            self.current_position = -1
            self.last_qty = qty
            self.last_signal_time = now
            print(f"[Strategy5] SELL {self.symbol} qty={qty} @ {price} (BB upper)")
            return

        # 平仓逻辑：回到均线附近
        if self.current_position == 1 and last >= last_ma and self.last_qty > 0:
            self.client.sell(self.symbol, self.last_qty)
            self.current_position = 0
            self.last_qty = 0
            self.last_signal_time = now
            print(f"[Strategy5] CLOSE LONG {self.symbol} @ {price} (mean revert)")

        if self.current_position == -1 and last <= last_ma and self.last_qty > 0:
            self.client.buy(self.symbol, self.last_qty)
            self.current_position = 0
            self.last_qty = 0
            self.last_signal_time = now
            print(f"[Strategy5] CLOSE SHORT {self.symbol} @ {price} (mean revert)")
