import pandas as pd
import numpy as np
from datetime import datetime, timedelta


class Strategy:
    """Strategy 4 — 1 分钟 EMA9/EMA21 + RSI 过滤的短线趋势策略。

    早期打包版本中该文件在 run() 处被截断并遗留一个单独的字符 `s`，导致语法错误，
    进而让整个策略管理器在运行该策略时持续报错。
    这里提供一个完整且与其它策略一致的实现。
    """

    def __init__(self, client, symbol: str = "QQQ", position_fraction: float = 0.1):
        self.client = client
        self.symbol = symbol
        self.position_fraction = position_fraction

        self.current_position = 0  # 1=多头, -1=空头, 0=空仓
        self.last_qty = 0
        self.last_signal_time = None

    def fetch_bars(self, limit: int = 300):
        """获取 1 分钟 K 线。"""
        try:
            bars = self.client.get_bars(self.symbol, "1Min", limit)
            if not bars:
                return None

            df = pd.DataFrame(
                {
                    "t": [b.timestamp for b in bars],
                    "o": [b.open for b in bars],
                    "h": [b.high for b in bars],
                    "l": [b.low for b in bars],
                    "c": [b.close for b in bars],
                    "v": [b.volume for b in bars],
                }
            )
            df.set_index("t", inplace=True)
            return df
        except Exception as e:
            print(f"[Strategy4] fetch_bars error: {e}")
            return None

    @staticmethod
    def rsi(series, length: int = 14):
        delta = series.diff()
        gain = np.where(delta > 0, delta, 0)
        loss = np.where(delta < 0, -delta, 0)
        roll_up = pd.Series(gain).rolling(length).mean()
        roll_down = pd.Series(loss).rolling(length).mean()
        rs = roll_up / roll_down
        return 100 - (100 / (1 + rs))

    def compute_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        df = df.copy()
        df["ema_fast"] = df["c"].ewm(span=9).mean()
        df["ema_slow"] = df["c"].ewm(span=21).mean()
        df["rsi"] = self.rsi(df["c"], 14)
        return df

    def generate_signal(self, df: pd.DataFrame) -> int:
        """返回 1=做多, -1=做空, 0=观望。"""
        last = df.iloc[-1]
        prev = df.iloc[-2]

        cross_up = last["ema_fast"] > last["ema_slow"] and prev["ema_fast"] <= prev["ema_slow"]
        cross_down = last["ema_fast"] < last["ema_slow"] and prev["ema_fast"] >= prev["ema_slow"]

        rsi_strong = last["rsi"] > 55
        rsi_weak = last["rsi"] < 45

        if cross_up and rsi_strong:
            return 1
        if cross_down and rsi_weak:
            return -1
        return 0

    def run(self):
        df = self.fetch_bars()
        if df is None or len(df) < 60:
            return

        df = self.compute_indicators(df)
        signal = self.generate_signal(df)
        if signal == 0:
            return

        now = datetime.utcnow()

        # 5 分钟内不重复同向开仓
        if self.last_signal_time and now - self.last_signal_time < timedelta(minutes=5):
            return

        price = float(df["c"].iloc[-1])
        buying_power = float(self.client.get_buying_power())
        qty = int((buying_power * float(self.position_fraction)) / price)
        if qty <= 0:
            return

        if signal == 1 and self.current_position <= 0:
            # 平空
            if self.current_position == -1 and self.last_qty > 0:
                self.client.buy(self.symbol, self.last_qty)
            # 开多
            self.client.buy(self.symbol, qty)
            self.current_position = 1
            self.last_qty = qty
            self.last_signal_time = now
            print(f"[Strategy4] BUY {self.symbol} qty={qty} @ {price}")

        elif signal == -1 and self.current_position >= 0:
            # 平多
            if self.current_position == 1 and self.last_qty > 0:
                self.client.sell(self.symbol, self.last_qty)
            # 开空
            self.client.sell(self.symbol, qty)
            self.current_position = -1
            self.last_qty = qty
            self.last_signal_time = now
            print(f"[Strategy4] SELL {self.symbol} qty={qty} @ {price}")
