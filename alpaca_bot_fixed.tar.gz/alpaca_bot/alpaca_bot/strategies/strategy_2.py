import pandas as pd
import numpy as np
from datetime import datetime, timedelta


class Strategy:
    """
    SuperTrend + EMA Trend Strategy for TSLA
    position_fraction 从 JSON 传入，例如 0.1
    symbol 从 JSON 传入，建议 TSLA
    """

    def __init__(self, client, symbol="TSLA", position_fraction=0.1):
        self.client = client
        self.symbol = symbol
        self.position_fraction = position_fraction

        # 当前持仓状态：1=多头，-1=空头，0=空仓
        self.current_position = 0
        self.last_qty = 0
        self.last_signal_time = None

    def fetch_bars(self, limit=250):
        """获取 5 分钟 K 线"""
        try:
            bars = self.client.get_bars(self.symbol, "5Min", limit)
            if bars is None or len(bars) == 0:
                return None

            df = pd.DataFrame([{
                "t": b.timestamp,
                "o": b.open,
                "h": b.high,
                "l": b.low,
                "c": b.close
            } for b in bars])

            df.set_index("t", inplace=True)
            return df

        except Exception as e:
            print(f"[Strategy2] Error fetching bars: {e}")
            return None

    def compute_supertrend(self, df, period=10, multiplier=3):
        """
        SuperTrend 计算
        """
        high = df["h"]
        low = df["l"]
        close = df["c"]

        # ATR
        df["tr"] = np.maximum(high - low,
                      np.maximum(abs(high - close.shift(1)),
                                 abs(low - close.shift(1))))
        df["atr"] = df["tr"].rolling(period).mean()

        # 基础带
        df["upperband"] = (high + low) / 2 + multiplier * df["atr"]
        df["lowerband"] = (high + low) / 2 - multiplier * df["atr"]

        # SuperTrend 主逻辑
        st = [0] * len(df)
        for i in range(1, len(df)):
            if close.iloc[i] > df["upperband"].iloc[i-1]:
                st[i] = df["lowerband"].iloc[i]
            elif close.iloc[i] < df["lowerband"].iloc[i-1]:
                st[i] = df["upperband"].iloc[i]
            else:
                st[i] = st[i-1]

        df["supertrend"] = st
        return df

    def compute_indicators(self, df):
        """EMA20 + SuperTrend"""
        df["ema20"] = df["c"].ewm(span=20).mean()
        df = self.compute_supertrend(df)
        return df

    def generate_signal(self, df):
        """
        产生买卖信号：
        多头：收盘价 > SuperTrend 且 EMA20 上升
        空头：收盘价 < SuperTrend 且 EMA20 下行
        """
        last = df.iloc[-1]
        prev = df.iloc[-2]

        trend_up = last["ema20"] > prev["ema20"]
        trend_down = last["ema20"] < prev["ema20"]

        if last["c"] > last["supertrend"] and trend_up:
            return 1     # 做多
        if last["c"] < last["supertrend"] and trend_down:
            return -1    # 做空

        return 0

    def run(self):
        """策略执行主入口"""
        df = self.fetch_bars()
        if df is None or len(df) < 50:
            return

        df = self.compute_indicators(df)
        signal = self.generate_signal(df)
        now = datetime.utcnow()

        # 冷却时间（10 分钟）
        if self.last_signal_time:
            if now - self.last_signal_time < timedelta(minutes=10):
                return

        price = df["c"].iloc[-1]
        buying_power = self.client.get_buying_power()

        qty = (buying_power * self.position_fraction) / price
        qty = int(qty)
        if qty <= 0:
            return

        # 信号处理逻辑
        if signal == 1 and self.current_position <= 0:
            # 平空
            if self.current_position == -1:
                self.client.buy(self.symbol, abs(self.last_qty))

            # 开多
            self.client.buy(self.symbol, qty)
            self.current_position = 1
            self.last_qty = qty
            self.last_signal_time = now
            print(f"[Strategy2] BUY {self.symbol} qty={qty} @ {price}")

        elif signal == -1 and self.current_position >= 0:
            # 平多
            if self.current_position == 1:
                self.client.sell(self.symbol, self.last_qty)

            # 开空
            self.client.sell(self.symbol, qty)
            self.current_position = -1
            self.last_qty = qty
            self.last_signal_time = now
            print(f"[Strategy2] SELL {self.symbol} qty={qty} @ {price}")

        else:
            return
