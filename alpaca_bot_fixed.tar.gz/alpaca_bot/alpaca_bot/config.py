from pathlib import Path

# ===== Alpaca API（使用你现在的 KEY）=====
ALPACA_API_KEY = "PKDM2WJOYL6JMOSAYPQK7VXDES"
ALPACA_API_SECRET = "y9g3L9Ud3Lo8EELZ6oGo6nPuiivrZQLkzMkv58BMHcv"
ALPACA_BASE_URL = "https://paper-api.alpaca.markets"

# ===== 策略列表：现在一共 6 个 =====
STRATEGY_NAMES = [
    "strategy_1",  # AMD  短线趋势策略
    "strategy_2",  # TSLA 均值回归策略
    "strategy_3",  # MU   突破跟踪策略
    "strategy_4",  # META 趋势+止损
    "strategy_5",  # 小盘高波动股（我帮你选）
    "strategy_6",  # 涨幅>5% 扫描+回撤 8% 卖出
]

# 轮询间隔（秒）—— 5 秒一次已经够频繁了
POLL_INTERVAL_SECONDS = 5

# ===== 数据目录（保存每个策略的状态 JSON）=====
# 说明：你 VPS 上一直把配置文件放在项目根目录的 data/ 下（例如 /root/alpaca_bot/data）。
# 早期版本把 DATA_DIR 指到了包目录 alpaca_bot/alpaca_bot/data，导致：
# - /open all 写入的是“包目录”的 data
# - 你手工改的 /root/alpaca_bot/data/*.json 机器人读不到
# 结果表现为：/open all 后策略看起来仍然是关闭；position_fraction 也总是回到默认值。
#
# 这里做一个兼容：优先使用“项目根目录”的 data/（存在则用），否则回退到包目录。
BASE_DIR = Path(__file__).resolve().parent              # .../alpaca_bot/alpaca_bot
REPO_DIR = BASE_DIR.parent                             # .../alpaca_bot

_preferred = REPO_DIR / "data"
DATA_DIR = _preferred if _preferred.exists() else (BASE_DIR / "data")
DATA_DIR.mkdir(parents=True, exist_ok=True)

# ===== Telegram（已填好你的机器人和 chat_id）=====
TELEGRAM_BOT_TOKEN = "8462685156:AAGjseFbvUNn5SmpJGpiHv3gYgXqsZUF0sk"
TELEGRAM_CHAT_ID = 5293784920
