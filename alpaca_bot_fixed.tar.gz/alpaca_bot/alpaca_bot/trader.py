from alpaca_bot.client import AlpacaClientSimple
import logging

logger = logging.getLogger(__name__)

client = AlpacaClientSimple()

def open_position(symbol: str, qty: float):
    """自动开仓（市价）"""
    logger.info(f"[TRADE] 开仓: {symbol}, 数量={qty}")
    return client.buy_market(symbol, qty)

def close_position(symbol: str):
    """自动平仓（市价）"""
    logger.info(f"[TRADE] 平仓: {symbol}")
    return client.close_position(symbol)

def current_qty(symbol: str) -> float:
    """返回当前持仓数量"""
    return client.get_position_qty(symbol)

def last_price(symbol: str) -> float:
    """返回最新价格"""
    return client.get_last_price(symbol)
