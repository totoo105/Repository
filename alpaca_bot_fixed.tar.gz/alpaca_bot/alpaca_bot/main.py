import time
import threading
import telebot

from alpaca_bot.config import TELEGRAM_BOT_TOKEN, POLL_INTERVAL_SECONDS
from alpaca_bot.manager import (
    load_all_strategies,
    run_all_strategies,
    get_strategy_status,
    start_strategy,
    stop_strategy,
    set_strategy_symbol,
    set_strategy_fraction,
    start_all,
    stop_all,
)
from alpaca_bot.client import AlpacaClientSimple
from alpaca_bot.performance import compute_performance
from alpaca_bot.notify import send_telegram_message


bot = telebot.TeleBot(TELEGRAM_BOT_TOKEN)
alpaca = AlpacaClientSimple()

# ========== HELP ==========
@bot.message_handler(commands=['help'])
def cmd_help(message):
    msg = (
        "🤖 *指令说明*\n\n"
        "/status - 查看所有策略状态\n"
        "/open 1 - 启动策略 1\n"
        "/stop 1 - 停止策略 1\n"
        "/open_all - 启动全部策略\n"
        "/stop_all - 停止全部策略\n"
        "/positions - 查看当前持仓\n"
        "/performance - 查看策略组合绩效\n"
        "/symbol 1 TSLA - 修改策略 1 标的\n"
        "/fraction 1 0.5 - 修改仓位比例\n"
    )
    bot.reply_to(message, msg, parse_mode="Markdown")


# ========== 状态 ==========
@bot.message_handler(commands=['status'])
def cmd_status(message):
    status = get_strategy_status()
    msg = "📊 *策略状态：*\n\n"
    for sid, data in status.items():
        msg += (
            f"策略 {sid} ： {'🟢运行中' if data['enabled'] else '🔴停止'}\n"
            f"  标的：{data['symbol']}\n"
            f"  仓位：{data['fraction']}\n\n"
        )
    bot.reply_to(message, msg, parse_mode="Markdown")


# ========== 单策略开关 ==========
@bot.message_handler(regexp=r"^/open\s+\d+$")
def cmd_open(message):
    sid = message.text.split()[1]
    start_strategy(sid)
    bot.reply_to(message, f"🟢 策略 {sid} 已启动！")


@bot.message_handler(regexp=r"^/stop\s+\d+$")
def cmd_stop(message):
    sid = message.text.split()[1]
    stop_strategy(sid)
    bot.reply_to(message, f"🔴 策略 {sid} 已停止！")


# ========== ALL ==========
@bot.message_handler(commands=['open_all'])
def cmd_open_all(message):
    start_all()
    bot.reply_to(message, "🟢 已启动所有策略！")


@bot.message_handler(commands=['stop_all'])
def cmd_stop_all(message):
    stop_all()
    bot.reply_to(message, "🔴 已停止所有策略！")


# ========== 设置标的 ==========
@bot.message_handler(regexp=r"^/symbol\s+\d+\s+[A-Za-z0-9\.\-]+$")
def cmd_symbol(message):
    _, sid, symbol = message.text.split()
    set_strategy_symbol(sid, symbol)
    bot.reply_to(message, f"📌 策略 {sid} 标的已修改为 {symbol}")


# ========== 设置仓位 ==========
@bot.message_handler(regexp=r"^/fraction\s+\d+\s+\d*\.?\d+$")
def cmd_fraction(message):
    _, sid, frac = message.text.split()
    set_strategy_fraction(sid, float(frac))
    bot.reply_to(message, f"💰 策略 {sid} 仓位比例设置为 {frac}")


# ========== 查看持仓 ==========
@bot.message_handler(commands=['positions'])
def cmd_positions(message):
    pos = alpaca.list_positions()
    if not pos:
        bot.reply_to(message, "📭 当前无持仓")
        return

    msg = "📌 *持仓列表：*\n\n"
    for p in pos:
        # alpaca_trade_api Position 对象字段：symbol/qty/market_value/unrealized_pl 等
        msg += (
            f"{getattr(p, 'symbol', '')} ： {getattr(p, 'qty', '')} 股\n"
            f"  市值：{getattr(p, 'market_value', '')}\n"
            f"  盈亏：{getattr(p, 'unrealized_pl', '')}\n\n"
        )
    bot.reply_to(message, msg, parse_mode="Markdown")


# ========== 查看组合绩效 ==========
@bot.message_handler(commands=['performance'])
def cmd_performance(message):
    perf = compute_performance()

    msg = (
        "📈 *组合绩效统计：*\n\n"
        f"总收益：{perf['total_pnl']}\n"
        f"年化收益：{perf['annual_return']}\n"
        f"胜率：{perf['win_rate'] * 100:.2f}%\n"
        f"夏普率：{perf['sharpe']}\n"
        f"总交易数：{perf['total_trades']}\n"
    )
    bot.reply_to(message, msg, parse_mode="Markdown")


# ========== 主循环 ==========
def main_loop():
    load_all_strategies()
    send_telegram_message("🤖 交易机器人已启动！")

    while True:
        run_all_strategies()
        time.sleep(POLL_INTERVAL_SECONDS)


def telegram_polling():
    bot.infinity_polling()


if __name__ == "__main__":
    threading.Thread(target=telegram_polling, daemon=True).start()
    main_loop()
