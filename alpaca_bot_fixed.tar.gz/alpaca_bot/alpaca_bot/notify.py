"""
notify.py
Telegram 通知模块
"""

import telebot

# 修复路径错误：全部改为从 alpaca_bot.config 导入
from alpaca_bot.config import TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID


# 初始化 Telegram bot
bot = telebot.TeleBot(TELEGRAM_BOT_TOKEN)


def send_telegram_message(text: str):
    """
    向 Telegram 发送通知消息
    """
    try:
        bot.send_message(TELEGRAM_CHAT_ID, text)
    except Exception as e:
        print(f"[notify] Telegram 发送消息失败: {e}")
