import json
import os

from alpaca_bot.config import DATA_DIR
# 使用基于 alpaca_trade_api 的统一客户端（包含：get_bars / get_buying_power / buy / sell / get_position_qty）
from alpaca_bot.client import AlpacaClientSimple

# 策略类
from alpaca_bot.strategies.strategy_1 import Strategy as Strategy1
from alpaca_bot.strategies.strategy_2 import Strategy as Strategy2
from alpaca_bot.strategies.strategy_3 import Strategy as Strategy3
from alpaca_bot.strategies.strategy_4 import Strategy as Strategy4
from alpaca_bot.strategies.strategy_5 import Strategy as Strategy5
from alpaca_bot.strategies.strategy_6 import Strategy as Strategy6

STRATEGY_CLASS_MAP = {
    "1": Strategy1,
    "2": Strategy2,
    "3": Strategy3,
    "4": Strategy4,
    "5": Strategy5,
    "6": Strategy6,
}

strategies = {}
alpaca_client = AlpacaClientSimple()


def cfg_path(sid: str) -> str:
    return os.path.join(DATA_DIR, f"strategy_{sid}.json")


def load_config(sid: str) -> dict:
    """安全读取配置"""
    path = cfg_path(sid)
    cfg = {
        "enabled": False,
        "symbol": "AAPL",
        "position_fraction": 1.0,
    }

    if not os.path.exists(path):
        return cfg

    try:
        with open(path, "r") as f:
            data = json.load(f)
        if isinstance(data, dict):
            cfg["enabled"] = bool(data.get("enabled", False))
            cfg["symbol"] = str(data.get("symbol", "AAPL"))
            cfg["position_fraction"] = float(data.get("position_fraction", 1.0))
    except:
        pass
    return cfg


def save_config(sid: str, cfg: dict):
    out = {
        "enabled": bool(cfg.get("enabled", False)),
        "symbol": str(cfg.get("symbol", "AAPL")),
        "position_fraction": float(cfg.get("position_fraction", 1.0)),
    }
    with open(cfg_path(sid), "w") as f:
        json.dump(out, f, indent=4)


# ----------------------
# 加载策略
# ----------------------
def load_all_strategies():
    global strategies

    for sid, StrategyClass in STRATEGY_CLASS_MAP.items():
        cfg = load_config(sid)
        strat = StrategyClass(alpaca_client)

        if hasattr(strat, "symbol"):
            strat.symbol = cfg["symbol"]
        if hasattr(strat, "position_fraction"):
            strat.position_fraction = cfg["position_fraction"]

        strategies[sid] = strat
        print(f"✔ Loaded Strategy {sid}")


# ----------------------
# 执行策略
# ----------------------
def run_all_strategies():
    for sid, strat in strategies.items():
        cfg = load_config(sid)
        if cfg["enabled"]:
            try:
                strat.position_fraction = cfg["position_fraction"]
                strat.run()
            except Exception as e:
                print(f"❌ Strategy {sid} error: {e}")


# ----------------------
# 控制函数（给 Telegram 用）
# ----------------------
def start_strategy(sid: str):
    cfg = load_config(sid)
    cfg["enabled"] = True
    save_config(sid, cfg)


def stop_strategy(sid: str):
    cfg = load_config(sid)
    cfg["enabled"] = False
    save_config(sid, cfg)


def start_all():
    for sid in STRATEGY_CLASS_MAP.keys():
        start_strategy(sid)


def stop_all():
    for sid in STRATEGY_CLASS_MAP.keys():
        stop_strategy(sid)


def set_strategy_symbol(sid: str, symbol: str):
    cfg = load_config(sid)
    cfg["symbol"] = symbol
    save_config(sid, cfg)


def set_strategy_fraction(sid: str, fraction: float):
    cfg = load_config(sid)
    cfg["position_fraction"] = float(fraction)
    save_config(sid, cfg)


def get_strategy_status():
    status = {}
    for sid in STRATEGY_CLASS_MAP.keys():
        cfg = load_config(sid)
        status[sid] = {
            "enabled": cfg["enabled"],
            "symbol": cfg["symbol"],
            "fraction": cfg["position_fraction"],
        }
    return status
