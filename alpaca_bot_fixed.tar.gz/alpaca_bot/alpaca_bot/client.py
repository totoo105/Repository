"""
统一封装 Alpaca API，供各个策略调用。
"""

from alpaca_trade_api.rest import REST, APIError
from .config import ALPACA_API_KEY, ALPACA_API_SECRET, ALPACA_BASE_URL
from .config import DATA_DIR

import json
import os
import time


class _Bar:
    """给策略层使用的轻量 Bar 适配器。"""

    __slots__ = ("timestamp", "open", "high", "low", "close", "volume")

    def __init__(self, *, timestamp, open, high, low, close, volume):
        self.timestamp = timestamp
        self.open = open
        self.high = high
        self.low = low
        self.close = close
        self.volume = volume


class AlpacaClient:
    def __init__(self):
        self.api = REST(
            ALPACA_API_KEY,
            ALPACA_API_SECRET,
            ALPACA_BASE_URL,
        )

    # ========== K 线 ==========
    def get_bars(self, symbol: str, timeframe: str, limit: int = 200):
        """获取 K 线并适配为策略层可遍历的 Bar 列表。

        说明：策略文件里假设每个 bar 有 timestamp/open/high/low/close/volume 字段。
        alpaca_trade_api 版本差异较大，这里做容错字段映射。
        """
        try:
            bars = self.api.get_bars(symbol, timeframe, limit=limit)
        except Exception as e:
            print(f"[AlpacaClient] get_bars({symbol},{timeframe},{limit}) error: {e}")
            return []

        out = []
        try:
            for b in bars:
                # alpaca_trade_api 的字段命名在不同版本里可能是 t/o/h/l/c/v 或 timestamp/open/... 
                ts = getattr(b, "t", None) or getattr(b, "timestamp", None)
                o = getattr(b, "o", None) if hasattr(b, "o") else getattr(b, "open", None)
                h = getattr(b, "h", None) if hasattr(b, "h") else getattr(b, "high", None)
                l = getattr(b, "l", None) if hasattr(b, "l") else getattr(b, "low", None)
                c = getattr(b, "c", None) if hasattr(b, "c") else getattr(b, "close", None)
                v = getattr(b, "v", None) if hasattr(b, "v") else getattr(b, "volume", None)
                out.append(_Bar(timestamp=ts, open=float(o), high=float(h), low=float(l), close=float(c), volume=float(v)))
        except Exception as e:
            print(f"[AlpacaClient] get_bars mapping error: {e}")
            return []

        return out

    # ========== 基础行情 ==========
    def get_last_price(self, symbol: str) -> float | None:
        """
        获取最新成交价，失败返回 None
        """
        try:
            trade = self.api.get_latest_trade(symbol)
            return float(trade.price)
        except Exception as e:
            print(f"[AlpacaClient] get_last_price({symbol}) error: {e}")
            return None

    # ========== 账户信息 ==========
    def get_buying_power(self) -> float:
        """
        当前可用 buying power
        """
        try:
            acc = self.api.get_account()
            return float(acc.buying_power)
        except Exception as e:
            print(f"[AlpacaClient] get_buying_power() error: {e}")
            return 0.0

    def list_positions(self):
        """返回持仓列表（用于 /positions）。"""
        try:
            return list(self.api.list_positions())
        except Exception as e:
            print(f"[AlpacaClient] list_positions() error: {e}")
            return []

    # ========== 交易日志 ==========
    def _trade_log_path(self) -> str:
        return os.path.join(str(DATA_DIR), "trades.json")

    def _append_trade_log(self, *, symbol: str, qty: float, side: str):
        """记录交易（用于 /performance）。"""
        try:
            path = self._trade_log_path()
            data = []
            if os.path.exists(path):
                try:
                    with open(path, "r") as f:
                        data = json.load(f) or []
                except Exception:
                    data = []

            price = self.get_last_price(symbol)
            data.append(
                {
                    "timestamp": time.time(),
                    "symbol": symbol,
                    "qty": float(qty),
                    "side": side,
                    "price": float(price) if price is not None else None,
                }
            )
            with open(path, "w") as f:
                json.dump(data, f, indent=4)
        except Exception as e:
            print(f"[AlpacaClient] write trades.json error: {e}")

    # ========== 持仓 ==========
    def get_position_qty(self, symbol: str) -> float:
        """
        当前持仓数量（可以为 0）
        """
        try:
            pos = self.api.get_position(symbol)
            return float(pos.qty)
        except APIError as e:
            # 没仓位通常是 404
            if "position does not exist" in str(e).lower() or e.status_code == 404:
                return 0.0
            print(f"[AlpacaClient] get_position_qty({symbol}) APIError: {e}")
            return 0.0
        except Exception as e:
            print(f"[AlpacaClient] get_position_qty({symbol}) error: {e}")
            return 0.0

    # ========== 下单 ==========
    def buy(self, symbol: str, qty: float, time_in_force: str = "day"):
        """
        市价买入
        """
        qty_int = int(qty)
        if qty_int <= 0:
            print(f"[AlpacaClient] buy({symbol}) qty <= 0，跳过")
            return None
        try:
            order = self.api.submit_order(
                symbol=symbol,
                qty=qty_int,
                side="buy",
                type="market",
                time_in_force=time_in_force,
            )
            print(f"[ORDER] BUY {symbol} x {qty_int}, id={order.id}")
            self._append_trade_log(symbol=symbol, qty=qty_int, side="buy")
            return order
        except Exception as e:
            print(f"[AlpacaClient] buy({symbol}, {qty_int}) error: {e}")
            return None

    def sell(self, symbol: str, qty: float, time_in_force: str = "day"):
        """
        市价卖出（平仓）
        """
        qty_int = int(qty)
        if qty_int <= 0:
            print(f"[AlpacaClient] sell({symbol}) qty <= 0，跳过")
            return None
        try:
            order = self.api.submit_order(
                symbol=symbol,
                qty=qty_int,
                side="sell",
                type="market",
                time_in_force=time_in_force,
            )
            print(f"[ORDER] SELL {symbol} x {qty_int}, id={order.id}")
            self._append_trade_log(symbol=symbol, qty=qty_int, side="sell")
            return order
        except Exception as e:
            print(f"[AlpacaClient] sell({symbol}, {qty_int}) error: {e}")
            return None


# 兼容以前你尝试 import 的类名
AlpacaClientSimple = AlpacaClient
