import requests
import json
import os
import time

from alpaca_bot.config import (
    ALPACA_API_KEY,
    ALPACA_API_SECRET,
    ALPACA_BASE_URL,
    DATA_DIR
)

TRADE_LOG = os.path.join(DATA_DIR, "trades.json")


def _load_trade_log():
    """加载交易日志文件"""
    if not os.path.exists(TRADE_LOG):
        return []
    try:
        with open(TRADE_LOG, "r") as f:
            return json.load(f)
    except:
        return []


def _save_trade_log(data):
    """保存交易日志"""
    with open(TRADE_LOG, "w") as f:
        json.dump(data, f, indent=4)


class AlpacaClientSimple:

    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            "APCA-API-KEY-ID": ALPACA_API_KEY,
            "APCA-API-SECRET-KEY": ALPACA_API_SECRET,
        })

        self.base_url = ALPACA_BASE_URL
        self.data_url = "https://data.alpaca.markets"

    # ----------------------------------------
    # 获取最新行情
    # ----------------------------------------
    def get_last_price(self, symbol: str):
        url = f"{self.data_url}/v2/stocks/{symbol}/quotes/latest"

        try:
            resp = self.session.get(url, timeout=5)
            resp.raise_for_status()
            data = resp.json()
            return data.get("quote", {}).get("ap")
        except Exception as e:
            print(f"[Alpaca] 获取价格失败 {symbol}: {e}")
            return None

    # ----------------------------------------
    # 查询持仓
    # ----------------------------------------
    def get_positions(self):
        url = f"{self.base_url}/v2/positions"
        try:
            resp = self.session.get(url)
            resp.raise_for_status()
            return resp.json()
        except Exception as e:
            print(f"[Alpaca] 获取持仓失败: {e}")
            return []

    # ----------------------------------------
    # 下单
    # ----------------------------------------
    def submit_order(self, symbol, qty, side, type="market", tif="day"):
        url = f"{self.base_url}/v2/orders"

        order = {
            "symbol": symbol,
            "qty": qty,
            "side": side,
            "type": type,
            "time_in_force": tif,
        }

        try:
            resp = self.session.post(url, json=order)
            resp.raise_for_status()
            data = resp.json()

            # 写入交易日志
            trades = _load_trade_log()
            trades.append({
                "timestamp": time.time(),
                "symbol": symbol,
                "qty": qty,
                "side": side,
                "price": self.get_last_price(symbol),
                "order_id": data.get("id"),
            })
            _save_trade_log(trades)

            print(f"[TRADE] {side.upper()} {qty} {symbol}")
            return data

        except Exception as e:
            print(f"[Alpaca] 下单失败: {e}")
            return None
