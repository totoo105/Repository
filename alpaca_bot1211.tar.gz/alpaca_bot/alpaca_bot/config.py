from pathlib import Path

# ===== Alpaca API（使用你现在的 KEY）=====
ALPACA_API_KEY = "PKDM2WJOYL6JMOSAYPQK7VXDES"
ALPACA_API_SECRET = "y9g3L9Ud3Lo8EELZ6oGo6nPuiivrZQLkzMkv58BMHcv"
ALPACA_BASE_URL = "https://paper-api.alpaca.markets"

# ===== 策略列表：现在一共 6 个 =====
STRATEGY_NAMES = [
    "strategy_1",  # AMD  短线趋势策略
    "strategy_2",  # TSLA 均值回归策略
    "strategy_3",  # MU   突破跟踪策略
    "strategy_4",  # META 趋势+止损
    "strategy_5",  # 小盘高波动股（我帮你选）
    "strategy_6",  # 涨幅>5% 扫描+回撤 8% 卖出
]

# 轮询间隔（秒）—— 5 秒一次已经够频繁了
POLL_INTERVAL_SECONDS = 5

# ===== 数据目录（保存每个策略的状态 JSON）=====
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)

# ===== Telegram（已填好你的机器人和 chat_id）=====
TELEGRAM_BOT_TOKEN = "8462685156:AAGjseFbvUNn5SmpJGpiHv3gYgXqsZUF0sk"
TELEGRAM_CHAT_ID = 5293784920
