import os
import json
import math
import time

from alpaca_bot.config import DATA_DIR

TRADE_LOG = os.path.join(DATA_DIR, "trades.json")


def load_trades():
    if not os.path.exists(TRADE_LOG):
        return []
    try:
        with open(TRADE_LOG, "r") as f:
            return json.load(f)
    except:
        return []


def compute_performance():
    trades = load_trades()
    if len(trades) < 2:
        return {
            "total_pnl": 0,
            "win_rate": 0,
            "total_trades": len(trades),
            "sharpe": 0,
            "annual_return": 0,
        }

    pnl_list = []
    last_price = {}

    # 计算每笔收益
    for t in trades:
        symbol = t["symbol"]
        side = t["side"]
        price = t["price"]
        qty = t["qty"]

        if side == "buy":
            last_price[symbol] = price
        elif side == "sell":
            if symbol in last_price:
                pnl = (price - last_price[symbol]) * qty
                pnl_list.append(pnl)
                del last_price[symbol]

    if not pnl_list:
        return {
            "total_pnl": 0,
            "win_rate": 0,
            "total_trades": len(trades),
            "sharpe": 0,
            "annual_return": 0,
        }

    # 总收益
    total_pnl = sum(pnl_list)

    # 胜率
    wins = len([p for p in pnl_list if p > 0])
    win_rate = wins / len(pnl_list)

    # 夏普率（简化版）
    avg = sum(pnl_list) / len(pnl_list)
    std = math.sqrt(sum((p - avg) ** 2 for p in pnl_list) / len(pnl_list))
    sharpe = avg / std * 16 if std != 0 else 0  # 假设一年 16 次交易周期

    # 年化收益（非常简化）
    start = trades[0]["timestamp"]
    end = trades[-1]["timestamp"]
    days = max(1, (end - start) / 86400)

    annual_return = (total_pnl / days) * 365

    return {
        "total_pnl": round(total_pnl, 2),
        "win_rate": round(win_rate, 4),
        "total_trades": len(pnl_list),
        "sharpe": round(sharpe, 4),
        "annual_return": round(annual_return, 2),
    }
