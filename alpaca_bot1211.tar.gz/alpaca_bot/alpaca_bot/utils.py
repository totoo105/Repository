import json
import os
from datetime import datetime

LOG_PATH = "/root/alpaca_bot/trade_log.json"


def log_trade(symbol: str, profit: float):
    record = {
        "time": datetime.utcnow().isoformat(),
        "symbol": symbol,
        "profit": profit
    }

    if os.path.exists(LOG_PATH):
        with open(LOG_PATH, "r") as f:
            data = json.load(f)
    else:
        data = []

    data.append(record)

    with open(LOG_PATH, "w") as f:
        json.dump(data, f, indent=4)
