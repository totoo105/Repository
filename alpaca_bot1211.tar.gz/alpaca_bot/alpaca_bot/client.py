"""
统一封装 Alpaca API，供各个策略调用。
"""

from alpaca_trade_api.rest import REST, APIError
from .config import ALPACA_API_KEY, ALPACA_API_SECRET, ALPACA_BASE_URL


class AlpacaClient:
    def __init__(self):
        self.api = REST(
            ALPACA_API_KEY,
            ALPACA_API_SECRET,
            ALPACA_BASE_URL,
        )

    # ========== 基础行情 ==========
    def get_last_price(self, symbol: str) -> float | None:
        """
        获取最新成交价，失败返回 None
        """
        try:
            trade = self.api.get_latest_trade(symbol)
            return float(trade.price)
        except Exception as e:
            print(f"[AlpacaClient] get_last_price({symbol}) error: {e}")
            return None

    # ========== 账户信息 ==========
    def get_buying_power(self) -> float:
        """
        当前可用 buying power
        """
        try:
            acc = self.api.get_account()
            return float(acc.buying_power)
        except Exception as e:
            print(f"[AlpacaClient] get_buying_power() error: {e}")
            return 0.0

    # ========== 持仓 ==========
    def get_position_qty(self, symbol: str) -> float:
        """
        当前持仓数量（可以为 0）
        """
        try:
            pos = self.api.get_position(symbol)
            return float(pos.qty)
        except APIError as e:
            # 没仓位通常是 404
            if "position does not exist" in str(e).lower() or e.status_code == 404:
                return 0.0
            print(f"[AlpacaClient] get_position_qty({symbol}) APIError: {e}")
            return 0.0
        except Exception as e:
            print(f"[AlpacaClient] get_position_qty({symbol}) error: {e}")
            return 0.0

    # ========== 下单 ==========
    def buy(self, symbol: str, qty: float, time_in_force: str = "day"):
        """
        市价买入
        """
        qty_int = int(qty)
        if qty_int <= 0:
            print(f"[AlpacaClient] buy({symbol}) qty <= 0，跳过")
            return None
        try:
            order = self.api.submit_order(
                symbol=symbol,
                qty=qty_int,
                side="buy",
                type="market",
                time_in_force=time_in_force,
            )
            print(f"[ORDER] BUY {symbol} x {qty_int}, id={order.id}")
            return order
        except Exception as e:
            print(f"[AlpacaClient] buy({symbol}, {qty_int}) error: {e}")
            return None

    def sell(self, symbol: str, qty: float, time_in_force: str = "day"):
        """
        市价卖出（平仓）
        """
        qty_int = int(qty)
        if qty_int <= 0:
            print(f"[AlpacaClient] sell({symbol}) qty <= 0，跳过")
            return None
        try:
            order = self.api.submit_order(
                symbol=symbol,
                qty=qty_int,
                side="sell",
                type="market",
                time_in_force=time_in_force,
            )
            print(f"[ORDER] SELL {symbol} x {qty_int}, id={order.id}")
            return order
        except Exception as e:
            print(f"[AlpacaClient] sell({symbol}, {qty_int}) error: {e}")
            return None


# 兼容以前你尝试 import 的类名
AlpacaClientSimple = AlpacaClient
