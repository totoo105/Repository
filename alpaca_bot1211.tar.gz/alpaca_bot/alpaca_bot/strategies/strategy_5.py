from alpaca_bot.strategies.base_strategy import BaseStrategy
import numpy as np


class Strategy(BaseStrategy):
    """
    Strategy 5 — 多指标趋势确认 + 仓位控制 + 自动下单
    """

    def __init__(self, client):
        super().__init__(client)
        self.symbol = "QQQ"
        self.position_fraction = 0.10  # 默认 10%

    # -------------------------
    # 工具方法
    # -------------------------
    def ema(self, series, length):
        return series.ewm(span=length, adjust=False).mean()

    def hma(self, series, length):
        """
        Hull Moving Average
        """
        half = int(length / 2)
        sqrt_len = int(np.sqrt(length))

        wma_half = series.rolling(half).mean()
        wma_full = series.rolling(length).mean()
        raw = 2 * wma_half - wma_full
        hma_series = raw.rolling(sqrt_len).mean()
        return hma_series

    def rsi(self, series, length=14):
        """RSI 指标"""
        delta = series.diff()
        gain = (delta.where(delta > 0, 0)).rolling(length).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(length).mean()
        rs = gain / loss
        return 100 - (100 / (1 + rs))

    # -------------------------
    # 主策略逻辑
    # -------------------------
    def run(self):
        # 获取最近 200 根 K 线
        bars = self.client.get_bars(self.symbol, limit=200)
        if bars is None or len(bars) < 50:
            print("Strategy 5: 数据不足")
            return

        close = bars["close"]

        # ======================
        # 指标计算
        # ======================
        ema20 = self.ema(close, 20)
        ema50 = self.ema(close, 50)
        ema100 = self.ema(close, 100)

        hma20 = self.hma(close, 20)
        hma50 = self.hma(close, 50)

        rsi14 = self.rsi(close, 14)

        latest = len(close) - 1

        # 趋势判断
        trend_up = ema20[latest] > ema50[latest] > ema100[latest]
        trend_down = ema20[latest] < ema50[latest] < ema100[latest]

        # HMA 金叉 / 死叉
        hma_cross_up = hma20[latest] > hma50[latest] and hma20[latest - 1] <= hma50[latest - 1]
        hma_cross_down = hma20[latest] < hma50[latest] and hma20[latest - 1] >= hma50[latest - 1]

        # RSI 超买超卖
        rsi_low = rsi14[latest] < 30
        rsi_high = rsi14[latest] > 70

        # ======================
        # 获取当前仓位
        # ======================
        pos_qty = self.client.get_position_qty(self.symbol)
        equity = self.client.get_account_equity()
        target_value = equity * self.position_fraction

        # ======================
        # 买入条件（趋势 + 金叉 + RSI 低位）
        # ======================
        if trend_up and hma_cross_up and rsi_low:
            qty = max(1, int(target_value / close[latest]))
            print(f"[Strategy 5] BUY signal — qty={qty}")

            self.client.submit_order(
                symbol=self.symbol,
                qty=qty,
                side="buy"
            )
            return

        # ======================
        # 卖出条件（趋势下行 + 死叉 + RSI 高位）
        # ======================
        if trend_down and hma_cross_down and rsi_high:
            if pos_qty > 0:
                print(f"[Strategy 5] SELL signal — qty={pos_qty}")

                self.client.submit_order(
                    symbol=self.symbol,
                    qty=pos_qty,
                    side="sell"
                )
            return

        print("[Strategy 5] No signal")
