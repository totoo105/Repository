import pandas as pd
import numpy as np
from datetime import datetime, timedelta


class Strategy:
    """
    Multi-Factor Trend Strategy for QQQ
    position_fraction 由 JSON 配置传入，如：0.1
    symbol 由 JSON 传入，本策略默认就是 QQQ
    """

    def __init__(self, client, symbol="QQQ", position_fraction=0.1):
        self.client = client
        self.symbol = symbol
        self.position_fraction = position_fraction

        # 状态变量
        self.current_position = 0  # 1=多头，-1=空头，0=空仓
        self.last_signal_time = None

    def fetch_bars(self, limit=200):
        """
        获取 5m K 线数据, 你的客户端应支持 get_bars(symbol, timeframe, limit)
        """
        try:
            bars = self.client.get_bars(self.symbol, "5Min", limit)
            if bars is None or len(bars) == 0:
                return None

            # 转成 DataFrame
            df = pd.DataFrame([{
                "t": b.timestamp,
                "o": b.open,
                "h": b.high,
                "l": b.low,
                "c": b.close,
                "v": b.volume
            } for b in bars])

            df.set_index("t", inplace=True)
            return df

        except Exception as e:
            print(f"[Strategy1] Error fetching bars: {e}")
            return None

    def compute_indicators(self, df):
        """
        计算多因子指标：
        - EMA20 趋势
        - MACD
        - RSI14
        """
        df["ema20"] = df["c"].ewm(span=20).mean()

        # MACD
        df["ema12"] = df["c"].ewm(span=12).mean()
        df["ema26"] = df["c"].ewm(span=26).mean()
        df["macd"] = df["ema12"] - df["ema26"]
        df["signal"] = df["macd"].ewm(span=9).mean()

        # RSI
        delta = df["c"].diff()
        gain = np.where(delta > 0, delta, 0)
        loss = np.where(delta < 0, -delta, 0)
        roll_up = pd.Series(gain).rolling(14).mean()
        roll_down = pd.Series(loss).rolling(14).mean()
        rs = roll_up / roll_down
        df["rsi"] = 100 - (100 / (1 + rs))

        return df

    def generate_signal(self, df):
        """
        基于多因子生成买卖信号
        return: 1=做多, -1=做空, 0=观望
        """
        last = df.iloc[-1]
        prev = df.iloc[-2]

        trend_up = last["ema20"] > prev["ema20"]
        trend_down = last["ema20"] < prev["ema20"]

        macd_cross_up = last["macd"] > last["signal"] and prev["macd"] <= prev["signal"]
        macd_cross_down = last["macd"] < last["signal"] and prev["macd"] >= prev["signal"]

        rsi_strong = last["rsi"] > 55
        rsi_weak = last["rsi"] < 45

        # 做多信号
        if trend_up and macd_cross_up and rsi_strong:
            return 1

        # 做空信号
        if trend_down and macd_cross_down and rsi_weak:
            return -1

        return 0

    def run(self):
        """
        主执行逻辑，每次 manager 调用都会运行
        """
        df = self.fetch_bars()
        if df is None or len(df) < 50:
            return

        df = self.compute_indicators(df)
        signal = self.generate_signal(df)

        now = datetime.utcnow()

        # 避免重复信号 spam（10 分钟内不重复执行同方向）
        if self.last_signal_time:
            if now - self.last_signal_time < timedelta(minutes=10):
                return

        # 当前市场价格
        price = df["c"].iloc[-1]

        # 账户可用资金
        buying_power = self.client.get_buying_power()

        qty = (buying_power * self.position_fraction) / price
        qty = int(qty)

        if qty <= 0:
            return

        # 执行信号逻辑
        if signal == 1 and self.current_position <= 0:
            # 平空
            if self.current_position == -1:
                self.client.buy(self.symbol, abs(self.last_qty))
            # 做多
            self.client.buy(self.symbol, qty)
            self.current_position = 1
            self.last_qty = qty
            self.last_signal_time = now
            print(f"[Strategy1] BUY {self.symbol} qty={qty} @ {price}")

        elif signal == -1 and self.current_position >= 0:
            # 平多
            if self.current_position == 1:
                self.client.sell(self.symbol, self.last_qty)
            # 做空
            self.client.sell(self.symbol, qty)
            self.current_position = -1
            self.last_qty = qty
            self.last_signal_time = now
            print(f"[Strategy1] SELL {self.symbol} qty={qty} @ {price}")

        else:
            # 无信号
            return
