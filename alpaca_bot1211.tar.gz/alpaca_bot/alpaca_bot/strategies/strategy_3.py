import pandas as pd
import numpy as np
from datetime import datetime, timedelta


class Strategy:
    """
    VWAP Trend Strategy for TQQQ
    position_fraction 从 JSON 传入，例如 0.1
    symbol 从 JSON 传入，建议 TQQQ
    """

    def __init__(self, client, symbol="TQQQ", position_fraction=0.1):
        self.client = client
        self.symbol = symbol
        self.position_fraction = position_fraction

        self.current_position = 0   # 1=多头，-1=空头，0=空仓
        self.last_qty = 0
        self.last_signal_time = None

    def fetch_bars(self, limit=250):
        """获取 5 分钟 K 线"""
        try:
            bars = self.client.get_bars(self.symbol, "5Min", limit)
            if not bars:
                return None

            df = pd.DataFrame([{
                "t": b.timestamp,
                "o": b.open,
                "h": b.high,
                "l": b.low,
                "c": b.close,
                "v": b.volume
            } for b in bars])

            df.set_index("t", inplace=True)
            return df

        except Exception as e:
            print(f"[Strategy3] Error fetching bars: {e}")
            return None

    def compute_indicators(self, df):
        """
        VWAP 计算：
        VWAP = sum(price * volume) / sum(volume)
        同时计算 EMA20 作为趋势过滤
        """
        df["pv"] = df["c"] * df["v"]
        df["cum_pv"] = df["pv"].cumsum()
        df["cum_vol"] = df["v"].cumsum()
        df["vwap"] = df["cum_pv"] / df["cum_vol"]

        df["ema20"] = df["c"].ewm(span=20).mean()
        return df

    def generate_signal(self, df):
        """
        交易信号：
        - 上涨趋势：EMA20 上行
        - 下跌趋势：EMA20 下行
        - 价格突破 / 跌破 VWAP
        """
        last = df.iloc[-1]
        prev = df.iloc[-2]

        trend_up = last["ema20"] > prev["ema20"]
        trend_down = last["ema20"] < prev["ema20"]

        if last["c"] > last["vwap"] and trend_up:
            return 1    # 做多

        if last["c"] < last["vwap"] and trend_down:
            return -1   # 做空

        return 0

    def run(self):
        df = self.fetch_bars()
        if df is None or len(df) < 30:
            return

        df = self.compute_indicators(df)
        signal = self.generate_signal(df)
        now = datetime.utcnow()

        # 冷却时间，避免信号震荡
        if self.last_signal_time:
            if now - self.last_signal_time < timedelta(minutes=10):
                return

        price = df["c"].iloc[-1]
        buying_power = self.client.get_buying_power()

        qty = (buying_power * self.position_fraction) / price
        qty = int(qty)
        if qty <= 0:
            return

        # 信号处理：开多 / 开空 / 平仓
        if signal == 1 and self.current_position <= 0:
            # 平空
            if self.current_position == -1:
                self.client.buy(self.symbol, abs(self.last_qty))

            # 开多
            self.client.buy(self.symbol, qty)
            self.current_position = 1
            self.last_qty = qty
            self.last_signal_time = now
            print(f"[Strategy3] BUY {self.symbol} qty={qty} @ {price}")

        elif signal == -1 and self.current_position >= 0:
            # 平多
            if self.current_position == 1:
                self.client.sell(self.symbol, self.last_qty)

            # 开空
            self.client.sell(self.symbol, qty)
            self.current_position = -1
            self.last_qty = qty
            self.last_signal_time = now
            print(f"[Strategy3] SELL {self.symbol} qty={qty} @ {price}")

        else:
            return
