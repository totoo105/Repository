import pandas as pd
import numpy as np
from datetime import datetime, timedelta


class Strategy:
    """
    Short-Term Scalper Strategy for QQQ
    - 使用 1 分钟 K 线
    - EMA9 / EMA21 趋势 + RSI 动能过滤
    - 由 JSON 配置传入 symbol / position_fraction
    """

    def __init__(self, client, symbol="QQQ", position_fraction=0.1):
        self.client = client
        self.symbol = symbol
        self.position_fraction = position_fraction

        self.current_position = 0   # 1=多头, -1=空头, 0=空仓
        self.last_qty = 0
        self.last_signal_time = None

    def fetch_bars(self, limit=300):
        """获取 1 分钟 K 线，用于高频短线"""
        try:
            bars = self.client.get_bars(self.symbol, "1Min", limit)
            if not bars:
                return None

            df = pd.DataFrame([{
                "t": b.timestamp,
                "o": b.open,
                "h": b.high,
                "l": b.low,
                "c": b.close,
                "v": b.volume
            } for b in bars])

            df.set_index("t", inplace=True)
            return df

        except Exception as e:
            print(f"[Strategy4] Error fetching bars: {e}")
            return None

    def compute_indicators(self, df):
        """
        指标：
        - EMA9 / EMA21
        - RSI14
        """
        df["ema_fast"] = df["c"].ewm(span=9).mean()
        df["ema_slow"] = df["c"].ewm(span=21).mean()

        # RSI
        delta = df["c"].diff()
        gain = np.where(delta > 0, delta, 0)
        loss = np.where(delta < 0, -delta, 0)
        roll_up = pd.Series(gain).rolling(14).mean()
        roll_down = pd.Series(loss).rolling(14).mean()
        rs = roll_up / roll_down
        df["rsi"] = 100 - (100 / (1 + rs))

        return df

    def generate_signal(self, df):
        """
        交易信号：
        多头：
          - EMA9 上穿 EMA21
          - 收盘价在 EMA9 上方
          - RSI > 55
        空头：
          - EMA9 下穿 EMA21
          - 收盘价在 EMA9 下方
          - RSI < 45
        """
        last = df.iloc[-1]
        prev = df.iloc[-2]

        fast = last["ema_fast"]
        slow = last["ema_slow"]
        fast_prev = prev["ema_fast"]
        slow_prev = prev["ema_slow"]

        # 金叉 / 死叉
        cross_up = fast > slow and fast_prev <= slow_prev
        cross_down = fast < slow and fast_prev >= slow_prev

        price_above_fast = last["c"] > fast
        price_below_fast = last["c"] < fast

        rsi_strong = last["rsi"] > 55
        rsi_weak = last["rsi"] < 45

        # 多头信号
        if cross_up and price_above_fast and rsi_strong:
            return 1

        # 空头信号
        if cross_down and price_below_fast and rsi_weak:
            return -1

        return 0

    def run(self):
        """策略执行主入口"""
        df = self.fetch_bars()
        if df is None or len(df) < 50:
            return

        df = self.compute_indicators(df)
        s
