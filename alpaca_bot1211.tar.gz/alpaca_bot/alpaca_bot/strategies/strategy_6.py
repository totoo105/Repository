import pandas as pd
import numpy as np
from datetime import datetime, timedelta


class Strategy:
    """
    Strategy 6: SPY 1-Minute Multi-Factor Day Trader (stock version)

    核心思想来自原 Pine Script:
    - 1 分钟 EMA5 / EMA13 判断短线方向
    - 5 分钟 EMA5 / EMA13 判断大一级趋势
    - RSI 动能过滤
    - MACD 及其斜率过滤
    - ADX 判断是否在趋势中
    - ATR RMS 控制波动强度
    - VWAP & 日内高低位置过滤
    - 避开当天第 5 根之前 & 最后一段时间过于极端位置
    """

    def __init__(self, client, symbol="SPY", position_fraction=0.1):
        self.client = client
        self.symbol = symbol
        self.position_fraction = position_fraction

        self.position = 0      # 1 = long, -1 = short, 0 = flat
        self.last_qty = 0
        self.entry_price = None
        self.entry_time = None
        self.cooldown_bars = 10  # 至少间隔 N 根 1 分钟 K 再开新仓

    # ----------------- 数据获取 -----------------

    def fetch_1m_bars(self, limit=400):
        try:
            bars = self.client.get_bars(self.symbol, "1Min", limit)
            if not bars:
                return None
            df = pd.DataFrame(
                {
                    "t": [b.timestamp for b in bars],
                    "o": [b.open for b in bars],
                    "h": [b.high for b in bars],
                    "l": [b.low for b in bars],
                    "c": [b.close for b in bars],
                    "v": [b.volume for b in bars],
                }
            )
            df.set_index("t", inplace=True)
            return df
        except Exception as e:
            print("[Strategy6] fetch_1m_bars error:", e)
            return None

    def fetch_5m_bars(self, limit=200):
        try:
            bars = self.client.get_bars(self.symbol, "5Min", limit)
            if not bars:
                return None
            df = pd.DataFrame(
                {
                    "t": [b.timestamp for b in bars],
                    "o": [b.open for b in bars],
                    "h": [b.high for b in bars],
                    "l": [b.low for b in bars],
                    "c": [b.close for b in bars],
                    "v": [b.volume for b in bars],
                }
            )
            df.set_index("t", inplace=True)
            return df
        except Exception as e:
            print("[Strategy6] fetch_5m_bars error:", e)
            return None

    # ----------------- 指标计算 -----------------

    @staticmethod
    def ema(series, span):
        return series.ewm(span=span).mean()

    @staticmethod
    def rsi(series, period=14):
        delta = series.diff()
        gain = (delta.where(delta > 0, 0)).rolling(period).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(period).mean()
        rs = gain / loss
        return 100 - (100 / (1 + rs))

    @staticmethod
    def macd(series, fast=12, slow=26, signal=9):
        ema_fast = series.ewm(span=fast).mean()
        ema_slow = series.ewm(span=slow).mean()
        macd_line = ema_fast - ema_slow
        signal_line = macd_line.ewm(span=signal).mean()
        hist = macd_line - signal_line
        return macd_line, signal_line, hist

    @staticmethod
    def atr(df, period=14):
        high = df["h"]
        low = df["l"]
        close = df["c"]
        tr = np.maximum(
            high - low,
            np.maximum(abs(high - close.shift()), abs(low - close.shift())),
        )
        return tr.rolling(period).mean()

    @staticmethod
    def adx(df, period=14):
        high = df["h"]
        low = df["l"]
        close = df["c"]

        up = high.diff()
        down = -low.diff()

        plus_dm = np.where((up > down) & (up > 0), up, 0.0)
        minus_dm = np.where((down > up) & (down > 0), down, 0.0)

        tr1 = high - low
        tr2 = abs(high - close.shift())
        tr3 = abs(low - close.shift())
        tr = np.maximum(tr1, np.maximum(tr2, tr3))

        atr = pd.Series(tr).rolling(period).mean()
        plus_di = 100 * pd.Series(plus_dm).rolling(period).mean() / atr
        minus_di = 100 * pd.Series(minus_dm).rolling(period).mean() / atr
        dx = 100 * (plus_di - minus_di).abs() / (plus_di + minus_di)
        adx = dx.rolling(period).mean()
        return adx

    @staticmethod
    def vwap_and_bands(df):
        # 当天内 VWAP + 简单上下轨
        df = df.copy()
        df["pv"] = df["c"] * df["v"]
        # 按日期分组
        df["date"] = df.index.date
        last_date = df["date"].iloc[-1]
        day_df = df[df["date"] == last_date]

        cum_pv = day_df["pv"].cumsum()
        cum_vol = day_df["v"].cumsum()
        vwap = cum_pv / cum_vol

        # 用 rolling std 近似 VWAP 带宽
        std = day_df["c"].rolling(20).std()
        upper = vwap + std
        lower = vwap - std
        return vwap.iloc[-1], upper.iloc[-1], lower.iloc[-1], day_df

    # ----------------- 信号逻辑 -----------------

    def generate_signal(self, df_1m, df_5m):
        """
        返回:
            1 = 做多信号
           -1 = 做空信号
            0 = 无操作
        """
        last = df_1m.iloc[-1]
        prev = df_1m.iloc[-2]

        # 1m EMA
        ema5 = self.ema(df_1m["c"], 5)
        ema13 = self.ema(df_1m["c"], 13)
        ema5_last, ema13_last = ema5.iloc[-1], ema13.iloc[-1]
        ema5_prev, ema13_prev = ema5.iloc[-2], ema13.iloc[-2]

        # 5m EMA
        ema5_5m = self.ema(df_5m["c"], 5)
        ema13_5m = self.ema(df_5m["c"], 13)
        ema5_5m_last, ema13_5m_last = ema5_5m.iloc[-1], ema13_5m.iloc[-1]

        # RSI(5) + signal(9)
        rsi_5 = self.rsi(df_1m["c"], 5)
        rsi_val = rsi_5.iloc[-1]
        rsi_sig = rsi_5.rolling(9).mean().iloc[-1]

        # MACD + slope
        macd_line, macd_sig, _ = self.macd(df_1m["c"], 12, 26, 9)
        macd_last = macd_line.iloc[-1]
        macd_3ago = macd_line.iloc[-4] if len(macd_line) >= 4 else macd_line.iloc[-2]
        macd_slope = (macd_last - macd_3ago) / 3

        # ATR RMS
        atr_val = self.atr(df_1m, 14)
        atr_sq = atr_val ** 2
        rms_atr = atr_sq.rolling(20).mean().pow(0.5)
        rms_atr_last = rms_atr.iloc[-1]

        # ADX
        adx_series = self.adx(df_1m, 14)
        adx_last = adx_series.iloc[-1]

        # VWAP + 当日高低
        vwap_mid, vwap_up, vwap_low, day_df = self.vwap_and_bands(df_1m)
        day_high = day_df["h"].max()
        day_low = day_df["l"].min()
        last_price = last["c"]

        # 计算当日内 bar index，用于简单时间过滤（去掉当天前几根 / 最后几根）
        idx_in_day = len(day_df) - 1  # 当日最后一根 index
        # 要求：至少第 5 根之后再交易
        if idx_in_day < 5:
            return 0

        # 趋势与过滤条件（参考 Pine 的 C1..C 系列）
        up_trend_1m = ema5_last > ema13_last
        down_trend_1m = ema5_last < ema13_last
        up_trend_5m = ema5_5m_last > ema13_5m_last
        down_trend_5m = ema5_5m_last < ema13_5m_last

        # RSI: 多头偏低位，空头偏高位
        rsi_ok_long = rsi_sig < 49
        rsi_ok_short = rsi_sig > 51

        # ADX: 是否在趋势中
        adx_trending = adx_last > 15

        # 波动：不要太高
        rms_ok = rms_atr_last < 0.8

        # 距离当日高低：不要太近
        dist_high = abs(day_high - last_price) / last_price
        dist_low = abs(last_price - day_low) / last_price
        far_from_high = dist_high > 0.0006
        far_from_low = dist_low > 0.0006

        # VWAP：多单不要跌破下轨，空单不要升破上轨太多
        above_vwap_low = last_price >= vwap_low
        below_vwap_up = last_price <= vwap_up

        # 多头信号
        if (
            up_trend_1m
            and up_trend_5m
            and rsi_ok_long
            and macd_slope > 0
            and adx_trending
            and rms_ok
            and far_from_high
            and above_vwap_low
        ):
            return 1

        # 空头信号
        if (
            down_trend_1m
            and down_trend_5m
            and rsi_ok_short
            and macd_slope < 0
            and adx_trending
            and rms_ok
            and far_from_low
            and below_vwap_up
        ):
            return -1

        return 0

    # ----------------- 执行逻辑 -----------------

    def run(self):
        df_1m = self.fetch_1m_bars()
        if df_1m is None or len(df_1m) < 100:
            return

        df_5m = self.fetch_5m_bars()
        if df_5m is None or len(df_5m) < 40:
            return

        now = datetime.utcnow()
        price = df_1m["c"].iloc[-1]

        # 简单的“日内”过滤（不做严格美股时间，只防止过度久持仓）
        # 若持仓超过 90 分钟，可以考虑减仓 / 平仓（这里仅用于演示，可保留简单逻辑）
        if self.position != 0 and self.entry_time:
            if now - self.entry_time > timedelta(minutes=120):
                # 超过 2 小时强制平仓
                if self.position == 1:
                    self.client.sell(self.symbol, self.last_qty)
                    print(f"[Strategy6] Force close LONG {self.symbol} qty={self.last_qty} (time)")
                elif self.position == -1:
                    self.client.buy(self.symbol, abs(self.last_qty))
                    print(f"[Strategy6] Force close SHORT {self.symbol} qty={self.last_qty} (time)")
                self.position = 0
                self.last_qty = 0
                self.entry_price = None
                self.entry_time = None
                return

        # 冷却：最近 N 根 1m 之内不重复新开仓
        if self.entry_time:
            last_bar_time = df_1m.index[-1]
            # 粗略以时间差估算 bar 数
            if last_bar_time - self.entry_time < timedelta(minutes=self.cooldown_bars):
                # 仍可管理已有仓位（止损/止盈），但不再新开
                self.manage_position(df_1m)
                return

        # 先管理已有仓位（止损 / 止盈）
        self.manage_position(df_1m)

        # 再找新信号
        signal = self.generate_signal(df_1m, df_5m)
        if signal == 0:
            return

        buying_power = self.client.get_buying_power()
        qty = int((buying_power * self.position_fraction) / price)
        if qty <= 0:
            return

        # 根据信号开仓
        if signal == 1 and self.position <= 0:
            # 平空
            if self.position == -1 and self.last_qty > 0:
                self.client.buy(self.symbol, self.last_qty)
                print(f"[Strategy6] Close SHORT {self.symbol} qty={self.last_qty} before LONG")
            # 开多
            self.client.buy(self.symbol, qty)
            self.position = 1
            self.last_qty = qty
            self.entry_price = price
            self.entry_time = df_1m.index[-1]
            print(f"[Strategy6] OPEN LONG {self.symbol} qty={qty} @ {price}")

        elif signal == -1 and self.position >= 0:
            # 平多
            if self.position == 1 and self.last_qty > 0:
                self.client.sell(self.symbol, self.last_qty)
                print(f"[Strategy6] Close LONG {self.symbol} qty={self.last_qty} before SHORT")
            # 开空
            self.client.sell(self.symbol, qty)
            self.position = -1
            self.last_qty = qty
            self.entry_price = price
            self.entry_time = df_1m.index[-1]
            print(f"[Strategy6] OPEN SHORT {self.symbol} qty={qty} @ {price}")

    def manage_position(self, df_1m):
        """简单的止盈/止损 + 反向信号平仓逻辑。"""
        if self.position == 0 or self.entry_price is None or self.last_qty <= 0:
            return

        price = df_1m["c"].iloc[-1]

        # 基于原 Pine 中 0.00075 设计一个较温和的止盈/止损
        sl_pct = 0.001   # 0.1%
        tp_pct = 0.002   # 0.2%

        long_sl = self.entry_price * (1 - sl_pct)
        long_tp = self.entry_price * (1 + tp_pct)
        short_sl = self.entry_price * (1 + sl_pct)
        short_tp = self.entry_price * (1 - tp_pct)

        if self.position == 1:
            # 多头止损
            if price <= long_sl:
                self.client.sell(self.symbol, self.last_qty)
                print(f"[Strategy6] LONG stop-loss {self.symbol} qty={self.last_qty} @ {price}")
                self.position = 0
                self.last_qty = 0
                self.entry_price = None
                self.entry_time = None
            # 多头止盈
            elif price >= long_tp:
                self.client.sell(self.symbol, self.last_qty)
                print(f"[Strategy6] LONG take-profit {self.symbol} qty={self.last_qty} @ {price}")
                self.position = 0
                self.last_qty = 0
                self.entry_price = None
                self.entry_time = None

        elif self.position == -1:
            # 空头止损
            if price >= short_sl:
                self.client.buy(self.symbol, self.last_qty)
                print(f"[Strategy6] SHORT stop-loss {self.symbol} qty={self.last_qty} @ {price}")
                self.position = 0
                self.last_qty = 0
                self.entry_price = None
                self.entry_time = None
            # 空头止盈
            elif price <= short_tp:
                self.client.buy(self.symbol, self.last_qty)
                print(f"[Strategy6] SHORT take-profit {self.symbol} qty={self.last_qty} @ {price}")
                self.position = 0
                self.last_qty = 0
                self.entry_price = None
                self.entry_time = None
