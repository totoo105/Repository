class BaseStrategy:
    """
    所有策略继承的基础类。
    必须实现 run() 方法。
    """
    def __init__(self, client):
        self.client = client
        self.symbol = None
        self.position_fraction = 1.0

    def run(self):
        raise NotImplementedError("Strategy must implement run()")
